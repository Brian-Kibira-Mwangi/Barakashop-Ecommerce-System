'use strict';

module.exports = {
  routes: [
    {
      method: "POST",
      path: "/inventories",
      handler: "inventory.create",
      config: {
        policies: [],
        auth: false,  // Change to true if authentication is required
      },
    },
    {
      method: "GET",
      path: "/inventories",
      handler: "inventory.find",
      config: {
        policies: [],
        auth: false, // Change to true if authentication is required
      },
    },
    {
      method: "GET",
      path: "/inventories/:id",
      handler: "inventory.findOne",
      config: {
        policies: [],
        auth: false, // Change to true if authentication is required
      },
    },
    {
      method: "POST",
      path: "/inventories/deleteInventoryItems",
      handler: "inventory.deleteInventoryItems",
      config: {
        policies: [],
        auth: false, // Change to true if authentication is required
      },
    },
  ],
};
