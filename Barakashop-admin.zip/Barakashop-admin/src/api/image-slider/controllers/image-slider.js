'use strict';

/**
 * image-slider controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::image-slider.image-slider');
