module.exports = {
    routes: [
      {
        method: "POST",
        path: "/reset-password",
        handler: "reset-password.updatePassword",
        config: {
          auth: false,  // Set to true if authentication is required
        },
      },
    ],
  };
  