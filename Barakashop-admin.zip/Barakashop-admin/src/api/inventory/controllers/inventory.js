'use strict';

const { parseMultipartData, sanitizeEntity } = require('@strapi/utils');

module.exports = {
  async create(ctx) {
    try {
      const { data } = ctx.request.body;

      if (!data) {
        return ctx.badRequest("⚠️ Missing required data.");
      }

      const newInventoryItem = await strapi.entityService.create('api::inventory.inventory', {
        data,
      });

      return ctx.send({ data: newInventoryItem }); // Wrap in `data` key
    } catch (error) {
      strapi.log.error("❌ Error creating inventory item:", error);
      return ctx.internalServerError("Failed to create inventory item.");
    }
  },

  async find(ctx) {
    try {
      const inventories = await strapi.entityService.findMany('api::inventory.inventory', {
        filters: ctx.query.filters || {},
        populate: ['Model_ID', 'Color_ID', 'Color_name', 'Brand'],
      });

      return ctx.send({ data: inventories }); // Wrap in `data` key
    } catch (error) {
      strapi.log.error("❌ Error fetching inventory items:", error);
      return ctx.internalServerError("Failed to fetch inventory items.");
    }
  },

  async findOne(ctx) {
    try {
      const { id } = ctx.params;

      const inventoryItem = await strapi.entityService.findOne('api::inventory.inventory', id, {
        populate: ['Model_ID', 'Color_ID', 'Color_name', 'Brand'],
      });

      if (!inventoryItem) {
        return ctx.notFound("⚠️ Inventory item not found.");
      }

      return ctx.send({ data: inventoryItem }); // Wrap in `data` key
    } catch (error) {
      strapi.log.error("❌ Error fetching inventory item:", error);
      return ctx.internalServerError("Failed to fetch inventory item.");
    }
  },

  async deleteInventoryItems(ctx) {
    try {
      const { itemIds } = ctx.request.body;

      if (!itemIds || !Array.isArray(itemIds) || itemIds.length === 0) {
        return ctx.badRequest("⚠️ No item IDs provided for deletion.");
      }

      // Log extracted item IDs before deletion
      console.log("🗑️ Extracted Inventory Item IDs to delete:", itemIds);

      // Use Knex to delete items directly from the PostgreSQL database
      const deletedRows = await strapi.db.connection('inventories')
        .whereIn('id', itemIds)
        .del();

      if (deletedRows > 0) {
        return ctx.send({ 
          data: {
            message: `✅ Successfully deleted ${deletedRows} inventory items.`,
            deletedCount: deletedRows,
          }
        });
      } else {
        return ctx.notFound("⚠️ No matching inventory items found for deletion.");
      }

    } catch (error) {
      strapi.log.error("❌ Error deleting inventory items:", error);
      return ctx.internalServerError("Failed to delete inventory items.");
    }
  }
};
