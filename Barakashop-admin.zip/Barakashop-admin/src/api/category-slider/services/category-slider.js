'use strict';

/**
 * category-slider service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::category-slider.category-slider');
