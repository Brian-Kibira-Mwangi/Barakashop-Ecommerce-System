'use strict';

/**
 * color controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::color.color');
