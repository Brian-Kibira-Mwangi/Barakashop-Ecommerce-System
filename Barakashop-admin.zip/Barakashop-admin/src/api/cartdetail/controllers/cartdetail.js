const { parseMultipartData, sanitizeEntity } = require('@strapi/utils');

module.exports = {
  async create(ctx) {
    try {
      const { data } = ctx.request.body; // Extract cart data

      if (!data) {
        return ctx.badRequest("Cart data is required");
      }

      // Create a new cart detail entry in PostgreSQL
      const cartDetail = await strapi.entityService.create("api::cartdetail.cartdetail", { data });

      return ctx.created(cartDetail);
    } catch (error) {
      console.error("❌ Error creating cart detail:", error);
      return ctx.internalServerError("Failed to create cart detail");
    }
  },

  async find(ctx) {
    try {
      // Pass ctx.query to apply filters from the request
      const cartDetails = await strapi.entityService.findMany("api::cartdetail.cartdetail", {
        filters: ctx.query.filters,
      });
  
      return ctx.send(cartDetails);
    } catch (error) {
      console.error("❌ Error fetching cart details:", error);
      return ctx.internalServerError("Failed to retrieve cart details");
    }
  },
  

  async findOne(ctx) {
    try {
      const { id } = ctx.params; // Get ID from request params

      if (!id) {
        return ctx.badRequest("Cart detail ID is required");
      }

      const cartDetail = await strapi.entityService.findOne("api::cartdetail.cartdetail", id);

      if (!cartDetail) {
        return ctx.notFound("Cart detail not found");
      }

      return ctx.send(cartDetail);
    } catch (error) {
      console.error("❌ Error fetching cart detail:", error);
      return ctx.internalServerError("Failed to retrieve cart detail");
    }
  },

  async deleteDirectly(ctx) {
    try {
      const { backendId } = ctx.request.body; // Get backendId from request body

      if (!backendId) {
        return ctx.badRequest("Backend ID is required");
      }

      const knex = strapi.db.connection; // Get direct DB connection

      // Execute raw SQL query to delete from PostgreSQL
      await knex('cartdetails')
        .where('id', backendId)
        .del();

      return ctx.send({ message: "✅ Item deleted directly from DB" });
    } catch (error) {
      console.error("❌ Error deleting item:", error);
      return ctx.internalServerError("Failed to delete item");
    }
  }
};
