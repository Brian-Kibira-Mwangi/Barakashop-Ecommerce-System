'use strict';

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::model.model', ({ strapi }) => ({
  
  // Find all models (with filtering support)
  async find(ctx) {
    try {
      const { query } = ctx;

      console.log("🔍 Filtering models with:", query.filters);

      const models = await strapi.entityService.findMany('api::model.model', {
        filters: query.filters,
        populate: '*', // Populate relations if needed
      });

      // Transform response to match required structure
      const formattedModels = models.map(model => ({
        id: model.id,
        documentId: model.documentId, 
        Model: model.Model,  
        Name: model.Name,    
        Price: model.Price,  
        Quantity: model.Quantity, 
        createdAt: model.createdAt,
        updatedAt: model.updatedAt,
        publishedAt: model.publishedAt,
        Features: model.Features, 
      }));

      return {
        data: formattedModels,
      };
    } catch (error) {
      console.error("🚨 Error in find:", error);
      return ctx.badRequest("Error fetching models");
    }
  },

  // Find a single model by ID
  async findOne(ctx) {
    try {
      const { id } = ctx.params;
      const model = await strapi.entityService.findOne('api::model.model', id, { populate: '*' });

      if (!model) {
        return ctx.notFound("Model not found");
      }

      // Format single model to match required structure
      const formattedModel = {
        id: model.id,
        documentId: model.documentId, 
        Model: model.Model,  
        Name: model.Name,    
        Price: model.Price,  
        Quantity: model.Quantity, 
        createdAt: model.createdAt,
        updatedAt: model.updatedAt,
        publishedAt: model.publishedAt,
        Features: model.Features, 
      };

      return {
        data: [formattedModel],
      };
    } catch (error) {
      console.error("🚨 Error in findOne:", error);
      return ctx.badRequest("Error fetching model");
    }
  },

  // Create a new model
  async create(ctx) {
    try {
      const newModel = await strapi.entityService.create('api::model.model', {
        data: ctx.request.body,
      });

      return newModel;
    } catch (error) {
      console.error("🚨 Error in create:", error);
      return ctx.badRequest("Error creating model");
    }
  },

  // Update an existing model
  async update(ctx) {
    try {
      const { id } = ctx.params;
      const updatedModel = await strapi.entityService.update('api::model.model', id, {
        data: ctx.request.body,
      });

      return updatedModel;
    } catch (error) {
      console.error("🚨 Error in update:", error);
      return ctx.badRequest("Error updating model");
    }
  },

  // Delete a model
  async delete(ctx) {
    try {
      const { id } = ctx.params;
      const deletedModel = await strapi.entityService.delete('api::model.model', id);

      return deletedModel;
    } catch (error) {
      console.error("🚨 Error in delete:", error);
      return ctx.badRequest("Error deleting model");
    }
  },
}));
