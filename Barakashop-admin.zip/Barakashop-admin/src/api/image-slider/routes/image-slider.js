'use strict';

/**
 * image-slider router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::image-slider.image-slider');
