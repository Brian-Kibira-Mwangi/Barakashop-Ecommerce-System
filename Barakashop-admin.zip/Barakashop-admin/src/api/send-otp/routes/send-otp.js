module.exports = {
    routes: [
      {
        method: "POST",
        path: "/send-otp",
        handler: "send-otp.sendOtp",
        config: {
          policies: [],
          auth: false, // Set to true if authentication is required
        },
      },
    ],
  };
  