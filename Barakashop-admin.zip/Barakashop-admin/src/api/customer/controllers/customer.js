"use strict";

const { parseMultipartData, sanitizeEntity } = require("@strapi/utils");

module.exports = {
  // 🔹 1️⃣ Create a New Customer
  async create(ctx) {
    try {
      const { data } = ctx.request.body;

      if (!data) {
        return ctx.badRequest("⚠️ Missing required data.");
      }

      const newCustomer = await strapi.entityService.create("api::customer.customer", { data });

      return ctx.send({ data: newCustomer }); // ✅ Wrap in `data` key
    } catch (error) {
      strapi.log.error("❌ Error creating customer:", error);
      return ctx.internalServerError("Failed to create customer.");
    }
  },

  // 🔹 2️⃣ Fetch All Customers
  async find(ctx) {
    try {
      console.log("🔎 Received filters:", ctx.query.filters); // ✅ Debug input filters
  
      const customers = await strapi.entityService.findMany("api::customer.customer", {
        filters: ctx.query.filters || {},
        populate: [],
      });
  
      console.log("✅ Customers fetched:", customers);
  
      return ctx.send({ data: customers });
    } catch (error) {
      console.error("❌ Error fetching customers:", error);
      return ctx.internalServerError("Failed to fetch customers.");
    }
  },  

  // 🔹 3️⃣ Fetch a Single Customer by ID
  async findOne(ctx) {
    try {
      const { id } = ctx.params;

      const customer = await strapi.entityService.findOne("api::customer.customer", id, {
        populate: [], // Adjust based on your relations
      });

      if (!customer) {
        return ctx.notFound("⚠️ Customer not found.");
      }

      return ctx.send({ data: customer }); // ✅ Wrap in `data` key
    } catch (error) {
      strapi.log.error("❌ Error fetching customer:", error);
      return ctx.internalServerError("Failed to fetch customer.");
    }
  },

  // 🔹 4️⃣ Update Customer Details & Email
  async updateCustomerDetails(ctx) {
  try {
    const { user, firstname, lastname, phonenumber,email } = ctx.request.body; // ✅ Use lowercase keys

    if (!user || (!firstname && !lastname && !phonenumber&&!email)) {
      return ctx.badRequest("⚠️ Missing required fields.");
    }

    const knex = strapi.db.connection;
    console.log("🔄 Updating details for Customer Username:", user);

    // 🔎 Use lowercase column names for the WHERE clause
    const existingCustomer = await knex("customers").where("user", user).first();

    if (!existingCustomer) {
      console.log("❌ Customer not found.");
      return ctx.notFound("⚠️ Customer not found.");
    }

    // 🔹 Prepare data for update
    const customerUpdateData = {};
    if (firstname) customerUpdateData.firstname = firstname;
    if (lastname) customerUpdateData.lastname = lastname;
    if (phonenumber) customerUpdateData.phonenumber = phonenumber;

    console.log("📤 Updating customer with:", customerUpdateData);

    // 🔹 Update Customer Table
    if (Object.keys(customerUpdateData).length > 0) {
      const updatedCustomers = await knex("customers")
        .where("user", user) // ✅ Match lowercase column name
        .update(customerUpdateData);

      console.log(`✅ Updated ${updatedCustomers} row(s) in customers table.`);
    }
    if (email) {
      const updatedUsers = await knex("up_users").where("username", user).update({ email });
      console.log(`✅ Updated ${updatedUsers} row(s) in users table.`);
    }

    return ctx.send({ message: "✅ User details updated successfully!" });

  } catch (error) {
    console.error("❌ Internal Server Error:", error);
    return ctx.internalServerError("Failed to update customer details.");
  }
},

  // 🔹 5️⃣ Delete Multiple Customers
  async deleteCustomers(ctx) {
    try {
      const { customerIds } = ctx.request.body;

      if (!customerIds || !Array.isArray(customerIds) || customerIds.length === 0) {
        return ctx.badRequest("⚠️ No customer IDs provided for deletion.");
      }

      console.log("🗑️ Extracted Customer IDs to delete:", customerIds);

      // Use Knex to delete items directly from PostgreSQL
      const deletedRows = await strapi.db.connection("customers")
        .whereIn("id", customerIds)
        .del();

      if (deletedRows > 0) {
        return ctx.send({ 
          data: {
            message: `✅ Successfully deleted ${deletedRows} customers.`,
            deletedCount: deletedRows,
          }
        });
      } else {
        return ctx.notFound("⚠️ No matching customers found for deletion.");
      }

    } catch (error) {
      strapi.log.error("❌ Error deleting customers:", error);
      return ctx.internalServerError("Failed to delete customers.");
    }
  }
};
