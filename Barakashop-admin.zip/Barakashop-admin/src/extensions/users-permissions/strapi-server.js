"use strict";

module.exports = (plugin) => {
  plugin.controllers.auth.callback = async (ctx) => {
    const response = await strapi
      .plugin("users-permissions")
      .controller("auth")
      .callback(ctx);

    if (response.jwt) {
      const user = await strapi.entityService.findOne(
        "plugin::users-permissions.user",
        response.user.id,
        {
          fields: ["username", "email"], 
        }
      );

      response.jwt = strapi.plugins["users-permissions"].services.jwt.issue({
        id: user.id,
        username: user.username,
        email: user.email,
      });

      console.log("✅ JWT with Username Injected:", response.jwt);
    }

    return response;
  };

  return plugin;
};
