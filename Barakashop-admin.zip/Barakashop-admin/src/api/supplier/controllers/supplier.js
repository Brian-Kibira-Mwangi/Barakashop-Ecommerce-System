'use strict';

/**
 * supplier controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::supplier.supplier');
