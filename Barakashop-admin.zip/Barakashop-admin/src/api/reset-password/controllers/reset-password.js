const bcrypt = require("bcryptjs");

module.exports = {
  async updatePassword(ctx) {
    try {
      console.log("Received password reset request:", ctx.request.body); // Debugging

      const { email, password } = ctx.request.body;

      if (!email || !password) {
        console.error("Missing email or password");
        return ctx.badRequest("Email and new password are required");
      }

      // Check if user exists
      const user = await strapi.db.query("plugin::users-permissions.user").findOne({ where: { email } });

      if (!user) {
        console.error("User not found for email:", email);
        return ctx.badRequest("User not found");
      }

      // Hash the new password before saving
      const hashedPassword = await bcrypt.hash(password, 10);

      // Update password in database
      await strapi.db.query("plugin::users-permissions.user").update({
        where: { id: user.id },
        data: { password: hashedPassword },  // Save hashed password
      });

      console.log("Password updated successfully for:", email);
      return ctx.send({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Error updating password:", error);
      return ctx.internalServerError("Failed to update password", { error: error.message });
    }
  },
};
