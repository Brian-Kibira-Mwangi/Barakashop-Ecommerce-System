'use strict';

/**
 * category-slider router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::category-slider.category-slider');
