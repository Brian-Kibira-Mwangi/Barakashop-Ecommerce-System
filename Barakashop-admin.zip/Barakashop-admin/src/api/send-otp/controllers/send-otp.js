const nodemailer = require("nodemailer");

module.exports = {
  async sendOtp(ctx) {
    try {
      const { email } = ctx.request.body;

      if (!email) {
        return ctx.badRequest("Email is required");
      }

      // Generate a 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      console.log("✅ Generated OTP:", otp, "for email:", email); // Log generated OTP

      // Save OTP to database
      const user = await strapi.db.query("plugin::users-permissions.user").findOne({ where: { email } });

      if (!user) {
        console.error("❌ User not found for email:", email);
        return ctx.badRequest("User not found");
      }

      await strapi.db.query("plugin::users-permissions.user").update({
        where: { id: user.id },
        data: { otp },
      });

      console.log("✅ OTP stored in DB:", otp, "for user:", email); // Log OTP storage

      const transporter = nodemailer.createTransport({
        service: "Gmail",
        auth: {
          user: "barakashop511@gmail.com", // Replace with your email
          pass: "dgwhmwfkgnemsivj", // 
        },
        tls: {
          rejectUnauthorized: false, // Ignore SSL certificate issues
        },
      });

      const mailOptions = {
        from: "barakashop511@gmail.com",
        to: email,
        subject: "Your OTP Code",
        text: `Your OTP code is ${otp}. It will expire in 10 minutes.`,
      };
      await transporter.sendMail(mailOptions);

      return ctx.send({ message: "OTP sent successfully" });
    } catch (error) {
      console.error("❌ Error sending OTP:", error);
      return ctx.internalServerError("Failed to send OTP", { error: error.message });
    }
  },
};
