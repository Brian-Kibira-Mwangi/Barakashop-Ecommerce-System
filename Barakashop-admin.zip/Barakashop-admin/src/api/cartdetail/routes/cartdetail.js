module.exports = {
    routes: [
      {
        method: "POST",
        path: "/cartDetails",
        handler: "cartdetail.create",
        config: {
          policies: [],
          auth: false,  // Change to true if authentication is required
        },
      },
      {
        method: "GET",
        path: "/cartDetails",
        handler: "cartdetail.find",
        config: {
          policies: [],
          auth: false, // Change to true if authentication is required
        },
      },
      {
        method: "GET",
        path: "/cartDetails/:id",
        handler: "cartdetail.findOne",
        config: {
          policies: [],
          auth: false, // Change to true if authentication is required
        },
      },
      {
        method: "POST",
        path: "/cartDetails/deleteDirectly",
        handler: "cartdetail.deleteDirectly",
        config: {
          policies: [],
          auth: false, // Change to true if authentication is required
        },
      },
    ],
  };
  