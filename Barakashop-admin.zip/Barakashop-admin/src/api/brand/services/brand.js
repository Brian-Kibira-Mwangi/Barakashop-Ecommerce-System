'use strict';

/**
 * brand service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::brand.brand');
