const nodemailer = require("nodemailer");

module.exports = {
  async sendOrderEmail(ctx) {
    try {
      const { email, orderId, status, items, totalPrice, unavailableItems } = ctx.request.body;

      if (!email || !orderId || !status || !items || !totalPrice) {
        return ctx.badRequest("Missing required fields");
      }

      let subject = "";
      let message = "";

      if (status === "success") {
        subject = `✅ Order Confirmation - ${orderId}`;
        message = `
          <h3>Thank you for your purchase!</h3>
          <p>Your order <strong>${orderId}</strong> has been successfully placed.</p>
          <h4>Ordered Items:</h4>
          <ul>
            ${items.map(item => `<li>${item.model} (${item.color}, ${item.storage}) - ${item.quantity} pcs</li>`).join("")}
          </ul>
          <p><strong>Total Price:</strong> Ksh ${totalPrice}</p>
          <p>We appreciate your business!</p>
        `;
      } else if (status === "partial") {
        subject = `⚠️ Partial Order Confirmation - ${orderId}`;
        message = `
          <h3>Partial Order Processed</h3>
          <p>Your order <strong>${orderId}</strong> has been partially processed. Some items were out of stock.</p>
          <h4>Ordered Items:</h4>
          <ul>
            ${items.map(item => `<li>${item.model} (${item.color}, ${item.storage}) - ${item.quantity} pcs</li>`).join("")}
          </ul>
          <h4>Unavailable Items:</h4>
          <ul>
          ${unavailableItems.map(item => {
            const missingQuantity = item.requestedQuantity - item.availableStock; // Calculate missingQuantity here
            return `<li>${item.model} (${item.color}, ${item.storage}) - ${missingQuantity} pcs missing</li>`;
          }).join("")}          
          </ul>
          <p><strong>Total Price Charged:</strong> Ksh ${totalPrice}</p>
          <p>Please contact customer support for assistance.</p>
        `;
      } else {
        subject = `❌ Order Failed - ${orderId}`;
        message = `
          <h3>Order Failed</h3>
          <p>Unfortunately, we couldn't fulfill your order <strong>${orderId}</strong> due to insufficient stock.</p>
      
          <h4>Items Ordered:</h4>
          <ul>
          ${
            unavailableItems && unavailableItems.length > 0
              ? unavailableItems.map(item => {
                  // Ensure missingQuantity is calculated correctly
                  return `<li>${item.model} (${item.color}, ${item.storage}) - ${item.requestedQuantity} pcs missing</li>`;
                }).join("")
              : "<li>All items were out of stock.</li>"
          }
          </ul>
      
          <h4>Unavailable Items:</h4>
          <ul>
            ${
              unavailableItems && unavailableItems.length > 0
                ? unavailableItems.map(item => {
                    // Ensure missingQuantity is calculated correctly
                    return `<li>${item.model} (${item.color}, ${item.storage}) - ${item.requestedQuantity} pcs missing</li>`;
                  }).join("")
                : "<li>All items were out of stock.</li>"
            }
          </ul>
      
          <p><strong>Total Amount Charged:</strong> Ksh ${totalPrice}</p>
          <p>Please contact customer support for further assistance.</p>
        `;
    }
        

      // Configure Nodemailer 
      const transporter = nodemailer.createTransport({
        service: "Gmail",
        auth: {
          user: "barakashop511@gmail.com", // Replace with your email
          pass: "dgwhmwfkgnemsivj", // Use an App Password, NOT your actual password
        },
        tls: {
          rejectUnauthorized: false, // Ignore SSL certificate issues
        },
      });

      // Email options
      const mailOptions = {
        from: "barakashop511@gmail.com",
        to: email,
        subject: subject,
        html: message,
      };

      // Send the email
      await transporter.sendMail(mailOptions);

      ctx.send({ message: "Order email sent successfully!" });
    } catch (error) {
      console.error("❌ Error sending order email:", error);
      ctx.internalServerError("Failed to send order email", { error: error.message });
    }
  },
};
