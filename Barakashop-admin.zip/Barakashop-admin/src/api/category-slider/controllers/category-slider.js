'use strict';

/**
 * category-slider controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::category-slider.category-slider');
