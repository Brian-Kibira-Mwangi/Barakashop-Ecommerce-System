module.exports = {
    routes: [
      {
        method: "POST",
        path: "/sendOrderEmail",
        handler: "send-order-email.sendOrderEmail",
        config: {
          policies: [],
          middlewares: [],
        },
      },
    ],
  };
  