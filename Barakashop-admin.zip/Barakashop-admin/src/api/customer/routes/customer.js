module.exports = {
    routes: [
      {
        method: "POST",
        path: "/customers",
        handler: "customer.create",
        config: { auth: false },
      },
      {
        method: "GET",
        path: "/customers",
        handler: "customer.find",
        config: { auth: false },
      },
      {
        method: "GET",
        path: "/customers/:id",
        handler: "customer.findOne",
        config: { auth: false },
      },
      {
        method: "POST",
        path: "/customers/update-details",
        handler: "customer.updateCustomerDetails",
        config: { auth: false },
      },
      {
        method: "DELETE",
        path: "/customers/delete",
        handler: "customer.deleteCustomers",
        config: { auth: false },
      },
    ],
  };
  