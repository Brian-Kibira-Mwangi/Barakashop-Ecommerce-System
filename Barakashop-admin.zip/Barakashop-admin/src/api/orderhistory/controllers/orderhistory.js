'use strict';

/**
 * orderhistory controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::orderhistory.orderhistory');
