'use strict';

/**
 * image-slider service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::image-slider.image-slider');
