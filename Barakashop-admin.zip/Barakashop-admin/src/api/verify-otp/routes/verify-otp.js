module.exports = {
    routes: [
      {
        method: "POST",
        path: "/verify-otp", 
        handler: "verify-otp.verifyOtp",
        config: {
          auth: false,  
        },
      },
    ],
  };
  