module.exports = (plugin) => {
    plugin.controllers.auth.register = async (ctx) => {
      try {
        const { firstname, lastname, ...rest } = ctx.request.body;
  
        // Call the default Strapi register function
        const response = await strapi
          .plugin("users-permissions")
          .controller("auth")
          .register(ctx);
  
        if (response.user && response.user.id) {
          // Update user with firstname & lastname
          await strapi.entityService.update("plugin::users-permissions.user", response.user.id, {
            data: { firstname, lastname },
          });
        }
  
        return response;
      } catch (error) {
        console.error("Registration error:", error);
        ctx.throw(500, "Registration failed");
      }
    };
  
    return plugin;
  };
  