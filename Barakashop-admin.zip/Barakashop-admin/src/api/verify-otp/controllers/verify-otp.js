module.exports = {
  async verifyOtp(ctx) {
    try {
      console.log("✅ Received OTP verification request:", ctx.request.body); // Log request

      const { email, otp } = ctx.request.body;

      if (!email || !otp) {
        console.error("❌ Missing email or OTP");
        return ctx.badRequest("Email and OTP are required");
      }

      // Find user by email
      const user = await strapi.db.query("plugin::users-permissions.user").findOne({ where: { email } });

      if (!user) {
        console.error("❌ User not found for email:", email);
        return ctx.badRequest("User not found");
      }

      console.log("✅ Stored OTP in DB:", user.otp, "Received OTP:", otp); // Log stored vs received OTP

      // Check if OTP matches
      if (user.otp !== otp) {
        console.error("❌ Incorrect OTP for user:", email);
        return ctx.badRequest("Incorrect OTP");
      }

      // ✅ Clear OTP after verification
      await strapi.db.query("plugin::users-permissions.user").update({
        where: { id: user.id },
        data: { otp: null },
      });

      console.log("✅ OTP verified successfully for:", email);
      return ctx.send({ message: "OTP verified successfully" });
    } catch (error) {
      console.error("❌ Error verifying OTP:", error);
      return ctx.internalServerError("Failed to verify OTP", { error: error.message });
    }
  },
};
